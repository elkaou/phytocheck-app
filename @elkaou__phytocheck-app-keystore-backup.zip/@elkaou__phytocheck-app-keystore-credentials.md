# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: 0266e2c282bcdf488b96c11c6184ec74
- Android key alias: c8753682762db9907fbe61b797980e4e
- Android key password: aa099bb6ea21465682bfd0e338bfa174
      